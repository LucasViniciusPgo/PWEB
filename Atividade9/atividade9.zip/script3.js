
let numeros = 0;
const myArraynum = [3];
let numbers = 0;
const myArray2 = [3];

function ordena(myArraynum) {
    return myArraynum.sort(function (a, b) { return a - b })
}

function maior(myArray2) {
    return Math.max.apply(null, myArray2)
}

for (let index = 0; index < 3; index++) {
    numeros = prompt("Informe os números desejados: ")
    myArraynum[index] = parseInt(numeros);
}

alert(ordena(myArraynum))

for (let i = 0; i < 3; i++) {
    numbers = prompt("Informe 3 números para comparar")
    myArray2[i] = parseInt(numbers);
}

alert(maior(myArray2));
