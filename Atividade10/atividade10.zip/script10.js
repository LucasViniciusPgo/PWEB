var aluno = new Object();
aluno.ra = "0030482111020"
aluno.nome = "Lucas";

var meuAluno = {};
meuAluno.ra = "0030482111021";
meuAluno.nome = "Pedro José";

var Alunos = {
    ra: "0030482111022",
    nome: "Luiz Henrique"
}

alert(aluno.ra + "\n" + aluno.nome + "\n" + "\n" + meuAluno.ra + "\n" + meuAluno.nome + "\n" + "\n" + Alunos.ra + "\n" + Alunos.nome)

