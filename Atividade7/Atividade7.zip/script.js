do {
    opcao = prompt(" 1 - Jogar com o PC " + " \n " + "2 - jogar com um amigo")
    opcao = parseInt(opcao)

    switch (opcao) {
        case 1:
            op = prompt("Informe pedra papel ou tesoura")

            var myArray = ['pedra', 'papel', 'tesoura'];
            var rand = Math.floor(Math.random() * myArray.length);
            var rValue = myArray[rand];

            if (rValue == op.toLowerCase()) {
                alert("EMPATE")
            }
            if (rValue == 'pedra' && op.toLowerCase() == 'tesoura') {
                alert("PC ganhou, ele escolheu " + rValue + "\n" + "Você escolheu " + op)
            }
            if (rValue == 'tesoura' && op.toLowerCase() == 'papel') {
                alert("PC ganhou, ele escolheu " + rValue + "\n" + "Você escolheu " + op)
            }
            if (rValue == 'papel' && op.toLowerCase() == 'pedra') {
                alert("PC ganhou, ele escolheu " + rValue + "\n" + "Você escolheu " + op)
            }
            if (op.toLowerCase() == "pedra" && rValue == 'tesoura') {
                alert("Você ganhou, escolheu " + op + "\n" + "PC escolheu " + rValue)
            }
            if (op.toLowerCase() == "tesoura" && rValue == 'papel') {
                alert("Você ganhou, escolheu " + op + "\n" + "PC escolheu " + rValue)
            }
            if (op.toLowerCase() == "papel" && rValue == 'pedra') {
                alert("Você ganhou, escolheu " + op + "\n" + "PC escolheu " + rValue)
            }
            break;
        case 2:
            jogador1 = prompt(" jogador 1 - Informe pedra, papel ou tesoura")
            jogador2 = prompt(" jogador 2 - Informe pedra, papel ou tesoura")

            if (jogador1.toLowerCase() == jogador2.toLowerCase()) {
                alert("EMPATE")
            }
            if (jogador1.toLowerCase() == 'pedra' && jogador2.toLowerCase() == 'tesoura') {
                alert("Jogador 1 ganhou, escolheu " + jogador1 + "\n" + "Jogador 2 escolheu " + jogador2)
            }
            if (jogador1.toLowerCase() == 'tesoura' && jogador2.toLowerCase() == 'papel') {
                alert("Jogador 1 ganhou, escolheu " + jogador1 + "\n" + "Jogador 2 escolheu " + jogador2)
            }
            if (jogador1.toLowerCase() == 'papel' && jogador2.toLowerCase() == 'pedra') {
                alert("Jogador 1 ganhou, escolheu " + jogador1 + "\n" + "Jogador 2 escolheu " + jogador2)
            }
            if (jogador2.toLowerCase() == "pedra" && jogador1.toLowerCase() == 'tesoura') {
                alert("Jogador 2 ganhou, escolheu " + jogador2 + "\n" + "Jogador 1 escolheu " + jogador1)
            }
            if (jogador2.toLowerCase() == "tesoura" && jogador1.toLowerCase() == 'papel') {
                alert("Jogador 2 ganhou, escolheu " + jogador2 + "\n" + "Jogador 1 escolheu " + jogador1)
            }
            if (jogador2.toLowerCase() == "papel" && jogador1.toLowerCase() == 'pedra') {
                alert("Jogador 2 ganhou, escolheu " + jogador2 + "\n" + "Jogador 1 escolheu " + jogador1)
            }
            break;
        default:
            break;
    }


} while (opcao < 3)