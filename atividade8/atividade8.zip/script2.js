var idade_v;
var idade_n;
var idade = [5];
var sexo = [5];
var opiniao = [5];
var qtdF = 0;
var qtdM = 0;
var qtdPessimo = 0;
var qtdBO = 0;
var porcentagem;
var TotalIdade = 0;
var media = 0;

for (let i = 0; i < 5; i++) {
    idade[i] = prompt("Informe a idade: ");
    if (i == 0) {
        idade_n = idade[i];
        idade_v = idade[i];
    }
    if (idade[i] > idade_v) {
        idade_v = idade[i];
    }
    else if (idade[i] < idade_n) {
        idade_n = idade[i];
    }

    sexo[i] = prompt("Informe o sexo: ");

    opiniao[i] = prompt("Informe a opinião sobre o filme:" + "\n" + "4 - ótimo" +
        "\n" + "3 - bom" + "\n" + "2 - regular" + "\n" + "1 - péssimo");
    parseInt(opiniao[i]);

    if (opiniao[i] == 1) {
        qtdPessimo += 1;
    }
    if (opiniao[i] == 3 || opiniao[i] == 4) {
        qtdBO += 1;
        porcentagem = parseFloat((parseInt(qtdBO) / 100) * 5);
    }
    if (sexo[i] == "F") {
        qtdF += 1;
    } else {
        qtdM += 1;
    }

    TotalIdade = parseInt(idade[i]) + TotalIdade;
}

media = parseFloat(parseInt(TotalIdade) / 5);


parseInt(qtdPessimo);
parseInt(qtdF);
parseInt(qtdM);

alert("Média da idade das pessoas que respoderam: " + media);
alert("idade da pessoa mais velha: " + idade_v);
alert("Idade pessoa mais nova: " + idade_n);
alert("Quantidade de pessoas que responderam péssimo: " + qtdPessimo);
alert("Porcentagem bom e ótimo: " + porcentagem + "%");
alert("Número de mulheres: " + qtdF);
alert("Número homens: " + qtdM);