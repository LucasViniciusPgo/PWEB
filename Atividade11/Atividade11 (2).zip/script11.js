function Retangulo(base, altura) {
    this.base = base;
    this.altura = altura;
    this.isAlive = true;
}

function calcArea(objRetangulo) {
    return objRetangulo.altura * objRetangulo.base;
}

var objRetangulo = new Retangulo(4, 3);

alert(calcArea(objRetangulo));

function Conta() {
    var nome;
    var nomBanco;
    var numConta;
    var saldo;
    this.setNome = function (nomes) {
        nome = nomes
    };
    this.getNome = function () {
        return nome;
    }
    this.setBanco = function (banco) {
        nomBanco = banco
    }
    this.getBanco = function () {
        return nomBanco
    }
    this.setNumConta = function (numeroConta) {
        numConta = numeroConta
    }
    this.getNumConta = function () {
        return numConta
    }
    this.setSaldo = function (valorSaldo) {
        saldo = valorSaldo
    }
    this.getSaldo = function () {
        return saldo
    }

}

function Corrente() {
    var saldoEs
    this.setSaldoEs = function (valorSaldo) {
        saldoEs = valorSaldo;
    };
    this.getSaldoEs = function () {
        return saldoEs;
    };
}

function Poupanca() {
    var juro
    var vencimento
    this.setJuro = function (valorJuro) {
        juro = valorJuro
    }
    this.getJuro = function () {
        return juro
    }
    this.setVen = function (data) {
        vencimento = data
    }
    this.getVen = function () {
        return vencimento
    }
}

Corrente.prototype = new Conta();
Poupanca.prototype = new Conta();

objCorrente = new Corrente();
objPoupanca = new Poupanca();

objCorrente.setNome("pedro")
objCorrente.setBanco("BR")
objCorrente.setNumConta("12")
objCorrente.setSaldo("500")
objCorrente.setSaldoEs("1000")

objPoupanca.setNome("Lucas")
objPoupanca.setBanco("SAN")
objPoupanca.setNumConta("13")
objPoupanca.setSaldo("500")
objPoupanca.setJuro("400")
objPoupanca.setVen("12/12/2022")

alert( "nome: " + objCorrente.getNome() + "\n" + "Banco: " +  objCorrente.getBanco() + "\n" + "NumConta: " + objCorrente.getNumConta() + "\n" + "Saldo: " + objCorrente.getSaldo() +
    "\n" + "Saldo Especial: " + objCorrente.getSaldoEs())

alert( "nome: " + objPoupanca.getNome() + "\n" + "Banco: " +  objPoupanca.getBanco() + "\n" + "NumConta: " + objPoupanca.getNumConta() + "\n" + "Saldo: " + objPoupanca.getSaldo() +
    "\n" + "Juros: " + objPoupanca.getJuro() + "\n" + "Vencimento: " + objPoupanca.getVen())
